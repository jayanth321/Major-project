#myfile = request.FILES['doc']
     #print(myfile.name) ## mysheet.xslx
     #fs = FileSystemStorage()
     #filename = fs.save(myfile.name, myfile)
     #fileurl = fs.url(filename)
     #ROOT_DIR1 = os.path.dirname(os.path.abspath(myfile.name))
       
     #xl_file = pd.read_csv(d)
     #new_data = xl_file.dropna(axis = 0, how ='any')
     #splitt=myfile.name
     #print(new_data)
     #imageName = splitt.split(".")[0]+'.png'
     #plt.plot(xl_file["Gender"], xl_file["calories_chicken"])
     ##plt.savefig(ROOT_DIR1+'\\media\\'+imageName)
     ##print(ROOT_DIR1+'\\media\\'+myfile.name+'.png')
     #Some()
    